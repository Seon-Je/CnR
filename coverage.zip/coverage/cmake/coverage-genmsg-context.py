# generated from genmsg/cmake/pkg-genmsg.context.in

messages_str = "/home/redone/catkin_ws/src/skku/CnR/coverage/msg/task_info.msg;/home/redone/catkin_ws/src/skku/CnR/coverage/msg/Robot1_coverage_info.msg;/home/redone/catkin_ws/src/skku/CnR/coverage/msg/Robot2_coverage_info.msg;/home/redone/catkin_ws/src/skku/CnR/coverage/msg/Robot3_coverage_info.msg;/home/redone/catkin_ws/src/skku/CnR/coverage/msg/Robot4_coverage_info.msg;/home/redone/catkin_ws/src/skku/CnR/coverage/msg/Robot5_coverage_info.msg;/home/redone/catkin_ws/src/skku/CnR/coverage/msg/Robot6_coverage_info.msg"
services_str = ""
pkg_name = "coverage"
dependencies_str = "std_msgs"
langs = "gencpp;geneus;genjava;genlisp;gennodejs;genpy"
dep_include_paths_str = "coverage;/home/redone/catkin_ws/src/skku/CnR/coverage/msg;std_msgs;/opt/ros/kinetic/share/std_msgs/cmake/../msg"
PYTHON_EXECUTABLE = "/usr/bin/python"
package_has_static_sources = '' == 'TRUE'
genmsg_check_deps_script = "/opt/ros/kinetic/share/genmsg/cmake/../../../lib/genmsg/genmsg_check_deps.py"
